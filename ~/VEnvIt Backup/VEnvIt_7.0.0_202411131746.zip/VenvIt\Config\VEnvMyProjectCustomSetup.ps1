Write-Host "Executing VEnvMyProjectCustomSetup.ps1"
