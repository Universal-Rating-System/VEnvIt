Write-Host "Executing C:\Users\hendr\AppData\Local\Temp\VenvIt_eccd7cfb-04db-4caa-9827-74c8e238d678\Program Files\VenvIt\Secrets\secrets.ps1"
