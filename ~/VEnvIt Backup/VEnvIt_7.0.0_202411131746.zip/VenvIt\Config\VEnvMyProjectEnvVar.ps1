Write-Host "Executing VEnvMyProjectEnvVar.ps1"
