Write-Host "Executing VEnvMyProjectInstall.ps1"
