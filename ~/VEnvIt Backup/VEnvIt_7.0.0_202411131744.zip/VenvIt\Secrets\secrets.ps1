Write-Host "Executing C:\Users\hendr\AppData\Local\Temp\VenvIt_e99b27d7-bc37-4771-99d3-9d361aa713a3\Program Files\VenvIt\Secrets\secrets.ps1"
